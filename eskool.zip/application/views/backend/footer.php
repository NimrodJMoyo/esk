
@<?php echo $school_name; ?>

	
<!-- Footer 

<footer class="page-footer font-medium text-warning " style="width:100%;background-color: #fff;">

    <!--FILL EMPTY SPACE-->
        <div class="" style="background-color: #fff;">
          <div class="container">
      
            
      
          </div>
        </div>
      
       

        <!-- Footer Links -->
        <div class="container text-center text-md-left mt-5" style="border-top: 2px solid rgb(2, 117, 216); margin-top: 0; width:auto">
          <div class="row mt-3 dark-grey-text">

            <div class="col-md-2 col-lg-3 col-xl-2 mb-4">
      
              <h6 class="text-uppercase font-weight-bolder">Mission Statement </h6>
              <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
              <p>Here is where the school's mission statement will go and be displayed.</p>

                   <!-- Social Media Platiforms -->
        <div class="row py-4 d-flex align-items-center">
      
          <div class="col-md-6 col-lg-7 text-center text-md-right">
            <a class="fb-ic">
              <i class="fa fa-whatsapp white-text mr-4"> </i>
            </a>
            <a class="tw-ic">
              <i class="fa fa-twitter white-text mr-4"> </i>
            </a>
            <a class="li-ic">
              <i class="fa fa-facebook white-text mr-4"> </i>
            </a>
            <a class="ins-ic">
              <i class="fa fa-instagram white-text"> </i>
            </a>
          </div>
        </div>
      
            </div>
            <!-- Grid column -->
      
            <!-- Grid column -->
            <div class="col-md-3 col-lg-4 col-xl-12 mx-auto mb-4">
      
              <!-- Links -->
              <h6 class="text-uppercase font-weight-bold">Contact School</h6>
              <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
              <p>
                <a class="dark-grey-text" href="#!">address goes here</a>
              </p>
              <p>
                <i class="fa fa-envelope mr-3"></i> school's@gmail.com</p>
              <p>
                <i class="fa fa-mobile-phone mr-3"></i> + 263 771 841 532</p>
              <p>
                <i class="fa fa-phone mr-3"></i> + 263 000 000</p>
                <p>
                    <i class="fa fa-link mr-3"></i> <a href="#" title="currently under mantainance"> Our Website</a></p>
              <p>
                <a class="dark-grey-text" href="#!"></a>
              </p>
      
            </div>
            <!-- Grid column -->
      
            <!-- Grid column -->
            <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
      
              <!-- Links -->
              <h6 class="text-uppercase font-weight-bold">Services</h6>
              <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
              <p>
                <a class="dark-grey-text" href="#!">service 1</a>
              </p>
              <p>service 2</p>
              <p>service 3</p>
              <p>service 4</p>
      
            </div>
            <!-- Grid column -->
      
            <!-- Grid column -->
            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
      
              <!-- Links -->
              <h6 class="text-uppercase font-weight-bold">Developers</h6>
              <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
              <p>
                <i class="fa fa-home mr-3"></i>Nimrod J Moyo</p>
              <p>
                <i class="fa fa-envelope mr-3"></i> nimrodjarimanimoyo@gmail.com</p>
              <p>
                <i class="fa fa-mobile-phone mr-3"></i> + 263 771 841 532</p>
              <p>
                <i class="fa fa-phone mr-3"></i> + 263 000 000</p>
                <p>
                    <i class="fa fa-link mr-3"></i> <a href="#" title="currently under mantainance"> Our Website</a></p>
               
            </div>
            <!-- Grid column -->
      
          </div>
          <!-- Grid row -->
      
        </div>
        <!-- Footer Links -->
      
        <!-- Copyright -->
        <div class="footer-copyright text-center text-black-50 py-3 bg-primary ti-world">
            <strong> - Developed by Nimrod J Moyo&trade; with the help of Optimum Linkup © 2019 Copyright </strong>
        </div>
        <!-- Copyright -->
      
      </footer>
      <!-- Footer -->