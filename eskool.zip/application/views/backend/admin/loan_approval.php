<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/lap.png"  alt="" />
	      
           
</div>