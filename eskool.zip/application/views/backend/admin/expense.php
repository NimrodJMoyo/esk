<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/ek.png"  alt="" />
	      
           
</div>